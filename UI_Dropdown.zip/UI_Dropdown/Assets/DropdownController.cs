using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class DropdownController : MonoBehaviour
{
    [SerializeField] Button[] dropdownButtons;
    [SerializeField] Button btnMain;
    private bool isOn = false;
    [SerializeField] RectTransform listRt;
    private List<DropdownButton> dropDownButtonList;
    private DropdownButton curDropdownButton;
    [SerializeField] Image imgSelect;

    private Color selectColor = new Color(0.858f, 0.858f, 0.858f, 1);
    private int mainDirectionIndex = 0;
    private bool isActive = true;

    private void Awake()
    {
        btnMain.onClick.AddListener(OnClickMainButton);

        ExchangeDropdown();
    }

    private void OnClickMainButton()
    {
        isOn = !isOn;
        listRt.gameObject.SetActive(isOn);
    }

    private void ExchangeDropdown()
    {
        isOn = false;
        dropDownButtonList = new List<DropdownButton>();

        int count = 0;
        SetDropdown(0, "Front", mainDirectionIndex, isActive, ref count);
        SetDropdown(1, "Back", mainDirectionIndex, isActive, ref count);
        SetDropdown(2, "Top", mainDirectionIndex, isActive, ref count);
        SetDropdown(3, "Bottom", mainDirectionIndex, isActive, ref count);
        SetDropdown(4, "Left", mainDirectionIndex, isActive, ref count);
        SetDropdown(5, "Right", mainDirectionIndex, isActive, ref count);

        imgSelect.sprite = curDropdownButton.icon.sprite;

        btnMain.gameObject.SetActive(true);
        listRt.gameObject.SetActive(false);
        SelectDropdownButton(mainDirectionIndex, TempEventAction);
    }

    private void SetDropdown(int index, string name, int mainDirectionIndex, bool isActive, ref int count)
    {
        if (isActive)
        {
            DropdownButton cdb = new DropdownButton();
            cdb.btnDropdown = dropdownButtons[index];
            cdb.icon = dropdownButtons[index].transform.Find("img_icon").GetComponent<Image>();
            cdb.checkGo = dropdownButtons[index].transform.Find("img_check").gameObject;
            cdb.index = count;
            cdb.name = name;

            int buttonIndex = count;
            dropdownButtons[index].onClick.RemoveAllListeners();
            dropdownButtons[index].onClick.AddListener(() => {
                SelectDropdownButton(buttonIndex, TempEventAction);
            });

            if (dropDownButtonList.Count == mainDirectionIndex)
            {
                curDropdownButton = cdb;
                cdb.btnDropdown.image.color = selectColor;
                cdb.checkGo.SetActive(true);
            }
            else
            {
                cdb.btnDropdown.image.color = Color.white;
                cdb.checkGo.SetActive(false);
            }

            count++;
            dropDownButtonList.Add(cdb);
        }
        dropdownButtons[index].gameObject.SetActive(isActive);
    }

    private void SelectDropdownButton(int index, UnityAction eventAction)
    {
        Debug.Log("Select Dropdown Button Index : " + index);

        if (curDropdownButton != null)
        {
            curDropdownButton.btnDropdown.image.color = Color.white;
            curDropdownButton.checkGo.SetActive(false);
        }

        curDropdownButton = dropDownButtonList[index];
        curDropdownButton.btnDropdown.image.color = selectColor;
        curDropdownButton.checkGo.SetActive(true);

        imgSelect.sprite = curDropdownButton.icon.sprite;
        isOn = false;
        listRt.gameObject.SetActive(isOn);

        eventAction();
    }

    private void TempEventAction()
    {
        Debug.Log("�̺�Ʈ : " + curDropdownButton.name);
    }
}

[System.Serializable]
public class DropdownButton
{
    public Button btnDropdown;
    public GameObject checkGo;
    public Image icon;
    public int index;
    public string name;
}